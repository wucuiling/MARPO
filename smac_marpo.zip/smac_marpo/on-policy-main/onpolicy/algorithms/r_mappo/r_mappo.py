import numpy as np
import torch
import torch.nn as nn
from onpolicy.utils.util import get_gard_norm, huber_loss, mse_loss
from onpolicy.utils.valuenorm import ValueNorm
from onpolicy.algorithms.utils.util import check
import warnings
from scipy.optimize import fsolve
from copy import deepcopy


def solve_kl_equation(kl_value):
    """
    Solve for clipping range [r_min, r_max] such that:
        -log(r) + r - 1 = kl_value

    This approximates KL(old || new), and the solution is used for adaptive clipping.
    """
    # Ensure kl_value is valid
    kl_value = float(max(0.0, kl_value))
    # kl_value = np.clip(kl_value, 1e-4, 0.05)

    def equation(x):
        return -np.log(x) + x - 1 - kl_value

    # Default PPO-like clip values (for ϵ ≈ 0.2)
    default_root1 = 0.8652
    default_root2 = 1.1482

    try:
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            root1 = fsolve(equation, 0.5, xtol=1e-8, maxfev=500)[0]
            root2 = fsolve(equation, 1.3, xtol=1e-8, maxfev=500)[0]

            if len(w) > 0 or root1 >= root2 or not (0.1 < root1 < 1 and 1 < root2 < 2):
                print(f"[Warning] Invalid KL roots for kl={kl_value:.5f}. Using defaults.")
                return default_root1, default_root2

            return root1, root2

    except Exception as e:
        print(f"[Error] KL solve failed for kl={kl_value:.5f}: {e}. Using defaults.")
        return default_root1, default_root2

def compute_kl(old_policy, new_policy, obs_batch, rnn_states_batch, masks_batch,
               available_actions_batch, step, total_steps):
    """
    Compute true and approximate KL divergence between new and old policy distributions.

    :param old_dists: distribution or list of distributions from old policy
    :param new_dists: distribution or list of distributions from new policy
    :return: (float, float) -> (approx_kl, biased_kl)
    """
    with torch.no_grad():
        old_dists = old_policy.actor.get_dist(
            obs_batch,
            rnn_states_batch,
            masks_batch,
            available_actions_batch
        )

    new_dists = new_policy.actor.get_dist(
        obs_batch,
        rnn_states_batch,
        masks_batch,
        available_actions_batch
    )

    if isinstance(old_dists, list):
        kl_divs = [
            torch.distributions.kl_divergence(old, new).sum(-1)
            for new, old in zip(new_dists, old_dists)
        ]
        approx_kl_div = torch.stack(kl_divs, dim=-1).sum(dim=-1).mean().item()
    else:
        approx_kl_div = torch.distributions.kl_divergence(old_dists, new_dists).mean().item()

    ####kl_approx_mean,biased_kl
    min_kl = 0.008  
    avg_kl = max(approx_kl_div, min_kl)
    total_steps = max(float(total_steps), 1.0)
    train_progress = min(step / total_steps, 1)
    ada_kl_bias = 0.08*(1-train_progress)
    biased_kl= avg_kl+ada_kl_bias
    return approx_kl_div,biased_kl



class R_MAPPO():
    """
    Trainer class for MAPPO to update policies.
    :param args: (argparse.Namespace) arguments containing relevant model, policy, and env information.
    :param policy: (R_MAPPO_Policy) policy to update.
    :param device: (torch.device) specifies the device to run on (cpu/gpu).
    """

    def __init__(self,
                 args,
                 policy,
                 device=torch.device("cpu")):

        self.device = device
        self.tpdv = dict(dtype=torch.float32, device=device)
        self.policy = policy

        self.clip_param = args.clip_param
        self.ppo_epoch = args.ppo_epoch
        self.num_mini_batch = args.num_mini_batch
        self.num_env_steps = args.num_env_steps
        self.data_chunk_length = args.data_chunk_length
        self.value_loss_coef = args.value_loss_coef
        self.entropy_coef = args.entropy_coef
        self.max_grad_norm = args.max_grad_norm
        self.huber_delta = args.huber_delta

        self._use_recurrent_policy = args.use_recurrent_policy
        self._use_naive_recurrent = args.use_naive_recurrent_policy
        self._use_max_grad_norm = args.use_max_grad_norm
        self._use_clipped_value_loss = args.use_clipped_value_loss
        self._use_huber_loss = args.use_huber_loss
        self._use_popart = args.use_popart
        self._use_valuenorm = args.use_valuenorm
        self._use_value_active_masks = args.use_value_active_masks
        self._use_policy_active_masks = args.use_policy_active_masks

        # new
        self.target_kl = 0.01 
        self.kl_update_beta = 0.08 
        self.r_min = 1 - self.clip_param
        self.r_max = 1 + self.clip_param

        assert (self._use_popart and self._use_valuenorm) == False, (
            "self._use_popart and self._use_valuenorm can not be set True simultaneously")

        if self._use_popart:
            self.value_normalizer = self.policy.critic.v_out
        elif self._use_valuenorm:
            self.value_normalizer = ValueNorm(1, device=self.device)
        else:
            self.value_normalizer = None

    def cal_value_loss(self, values, value_preds_batch, return_batch, active_masks_batch):
        """
        Calculate value function loss.
        :param values: (torch.Tensor) value function predictions.
        :param value_preds_batch: (torch.Tensor) "old" value  predictions from data batch (used for value clip loss)
        :param return_batch: (torch.Tensor) reward to go returns.
        :param active_masks_batch: (torch.Tensor) denotes if agent is active or dead at a given timesep.

        :return value_loss: (torch.Tensor) value function loss.
        """
        value_pred_clipped = value_preds_batch + (values - value_preds_batch).clamp(-self.clip_param,
                                                                                    self.clip_param)
        if self._use_popart or self._use_valuenorm:
            self.value_normalizer.update(return_batch)
            error_clipped = self.value_normalizer.normalize(return_batch) - value_pred_clipped
            error_original = self.value_normalizer.normalize(return_batch) - values
        else:
            error_clipped = return_batch - value_pred_clipped
            error_original = return_batch - values

        if self._use_huber_loss:
            value_loss_clipped = huber_loss(error_clipped, self.huber_delta)
            value_loss_original = huber_loss(error_original, self.huber_delta)
        else:
            value_loss_clipped = mse_loss(error_clipped)
            value_loss_original = mse_loss(error_original)

        if self._use_clipped_value_loss:
            value_loss = torch.max(value_loss_original, value_loss_clipped)
        else:
            value_loss = value_loss_original

        if self._use_value_active_masks:
            value_loss = (value_loss * active_masks_batch).sum() / active_masks_batch.sum()
        else:
            value_loss = value_loss.mean()

        return value_loss

    ###

    def ppo_update(self, sample, old_policy, step, update_actor=True):
        """
        Update actor and critic networks.
        :param sample: (Tuple) contains data batch with which to update networks.
        :update_actor: (bool) whether to update actor network.

        :return value_loss: (torch.Tensor) value function loss.
        :return critic_grad_norm: (torch.Tensor) gradient norm from critic up9date.
        ;return policy_loss: (torch.Tensor) actor(policy) loss value.
        :return dist_entropy: (torch.Tensor) action entropies.
        :return actor_grad_norm: (torch.Tensor) gradient norm from actor update.
        :return imp_weights: (torch.Tensor) importance sampling weights.
        """
        (share_obs_batch, obs_batch, next_share_obs_batch, next_obs_batch,
         rnn_states_batch, rnn_states_critic_batch,
         actions_batch, next_actions_batch,
         value_preds_batch, return_batch,
         valid_mask, masks_batch, next_masks_batch,  
         active_masks_batch, next_active_masks_batch,
         next_adv_targ, adv_targ,
         available_actions_batch, next_available_actions_batch,
         next_old_action_log_probs_batch, old_action_log_probs_batch) = sample

        share_obs_batch = check(share_obs_batch).to(**self.tpdv)
        obs_batch = check(obs_batch).to(**self.tpdv)
        next_share_obs_batch = check(next_share_obs_batch).to(**self.tpdv)
        next_obs_batch = check(next_obs_batch).to(**self.tpdv)

        rnn_states_batch = check(rnn_states_batch).to(**self.tpdv)
        rnn_states_critic_batch = check(rnn_states_critic_batch).to(**self.tpdv)

        actions_batch = check(actions_batch).to(**self.tpdv)
        next_actions_batch = check(next_actions_batch).to(**self.tpdv)

        value_preds_batch = check(value_preds_batch).to(**self.tpdv)
        return_batch = check(return_batch).to(**self.tpdv)

        valid_mask = check(valid_mask).to(**self.tpdv)
        masks_batch = check(masks_batch).to(**self.tpdv)
        next_masks_batch = check(next_masks_batch).to(**self.tpdv)

        active_masks_batch = check(active_masks_batch).to(**self.tpdv)
        next_active_masks_batch = check(next_active_masks_batch).to(**self.tpdv)

        next_adv_targ = check(next_adv_targ).to(**self.tpdv)
        adv_targ = check(adv_targ).to(**self.tpdv)

        available_actions_batch = check(available_actions_batch).to(**self.tpdv)
        next_available_actions_batch = check(next_available_actions_batch).to(**self.tpdv)

        next_old_action_log_probs_batch = check(next_old_action_log_probs_batch).to(**self.tpdv)
        old_action_log_probs_batch = check(old_action_log_probs_batch).to(**self.tpdv)



        # Reshape to do in a single forward pass for all steps
        values, action_log_probs, dist_entropy = self.policy.evaluate_actions(share_obs_batch,
                                                                              obs_batch,
                                                                              rnn_states_batch,
                                                                              rnn_states_critic_batch,
                                                                              actions_batch,
                                                                              masks_batch,
                                                                              available_actions_batch,
                                                                              active_masks_batch)
        # actor update
        # imp_weights = torch.exp(action_log_probs - old_action_log_probs_batch)
        # surr1 = imp_weights * adv_targ
        # surr2 = torch.clamp(imp_weights, 1.0 - self.clip_param, 1.0 + self.clip_param) * adv_targ

        imp_weights = torch.exp(action_log_probs - old_action_log_probs_batch)


        kl_mean, biased_kl = compute_kl(old_policy, self.policy, obs_batch, rnn_states_batch, masks_batch,
                                        available_actions_batch, step, self.num_env_steps)

        self.target_kl = (1 - self.kl_update_beta) * self.target_kl + self.kl_update_beta * biased_kl


        self.r1_min, self.r1_max = solve_kl_equation(self.target_kl) 
        r2_min, r2_max = self.r1_min, self.r1_max

        surr1 = imp_weights * adv_targ
        surr2 = torch.clamp(imp_weights, self.r_min, self.r_max) * adv_targ

        if self._use_policy_active_masks:
            policy_action_loss = (-torch.sum(torch.min(surr1, surr2),
                                             dim=-1,
                                             keepdim=True) * active_masks_batch).sum() / active_masks_batch.sum()
        else:
            policy_action_loss = -torch.sum(torch.min(surr1, surr2), dim=-1, keepdim=True).mean()

        
        
        # ====== 反思机制，新增部分 ======

        _, next_action_log_probs, _ = self.policy.evaluate_actions(
            next_share_obs_batch,
            next_obs_batch,
            rnn_states_batch,
            rnn_states_critic_batch,
            next_actions_batch,
            next_masks_batch,
            next_available_actions_batch,
            next_active_masks_batch
        )
        next_imp_weights = torch.exp(next_action_log_probs - next_old_action_log_probs_batch)  # 前面tensor，后面numpy
        next_surr1 = imp_weights * next_imp_weights * next_adv_targ

        next_surr2 = torch.clamp(imp_weights, self.r1_min, self.r1_max) * \
                     torch.clamp(next_imp_weights,r2_min, r2_max) * next_adv_targ

        if self._use_policy_active_masks:
            reflection_masks = active_masks_batch * valid_mask
            next_policy_action_loss = (-torch.sum(torch.min(next_surr1, next_surr2), dim=-1,
                                                  keepdim=True) * reflection_masks).sum() / (
                                                  reflection_masks.sum().clamp(min=1.0))
        else:
            next_loss = -torch.sum(torch.min(next_surr1, next_surr2), dim=-1, keepdim=True) * valid_mask
            next_policy_action_loss = next_loss.sum() / valid_mask.sum().clamp(min=1.0)

        total_policy_loss = policy_action_loss + 0.3 * next_policy_action_loss

        # ====== 反思机制结束 ======
        


        self.policy.actor_optimizer.zero_grad()

        if update_actor:
            (total_policy_loss - dist_entropy * self.entropy_coef).backward()

            if self._use_max_grad_norm:
                actor_grad_norm = nn.utils.clip_grad_norm_(self.policy.actor.parameters(), self.max_grad_norm)
            else:
                actor_grad_norm = get_gard_norm(self.policy.actor.parameters())

            self.policy.actor_optimizer.step()
        else:
            actor_grad_norm = 0.0

        # critic update
        value_loss = self.cal_value_loss(values, value_preds_batch, return_batch, active_masks_batch)

        self.policy.critic_optimizer.zero_grad()

        (value_loss * self.value_loss_coef).backward()

        if self._use_max_grad_norm:
            critic_grad_norm = nn.utils.clip_grad_norm_(self.policy.critic.parameters(), self.max_grad_norm)
        else:
            critic_grad_norm = get_gard_norm(self.policy.critic.parameters())

        self.policy.critic_optimizer.step()

        return value_loss, critic_grad_norm, total_policy_loss, dist_entropy, actor_grad_norm, imp_weights, self.r1_min, self.r1_max, self.target_kl, kl_mean,biased_kl, r2_min,r2_max

    def train(self, buffer, step , update_actor=True):
        """
        Perform a training update using minibatch GD.
        :param buffer: (SharedReplayBuffer) buffer containing training data.
        :param update_actor: (bool) whether to update actor network.

        :return train_info: (dict) contains information regarding training update (e.g. loss, grad norms, etc).
        """
        if self._use_popart or self._use_valuenorm:
            advantages = buffer.returns[:-1] - self.value_normalizer.denormalize(buffer.value_preds[:-1])
        else:
            advantages = buffer.returns[:-1] - buffer.value_preds[:-1]
        advantages_copy = advantages.copy()
        advantages_copy[buffer.active_masks[:-1] == 0.0] = np.nan
        mean_advantages = np.nanmean(advantages_copy)
        std_advantages = np.nanstd(advantages_copy)
        advantages = (advantages - mean_advantages) / (std_advantages + 1e-5)

        train_info = {}

        train_info['value_loss'] = 0
        train_info['policy_loss'] = 0
        train_info['dist_entropy'] = 0
        train_info['actor_grad_norm'] = 0
        train_info['critic_grad_norm'] = 0
        train_info['ratio'] = 0
        train_info['r1_min'] = 0
        train_info['r2_min'] = 0
        train_info['r1_max'] = 0
        train_info['r2_max'] = 0
        train_info['target_kl'] = 0
        train_info['kl_approx_mean'] = 0
        train_info['biased_kl'] = 0

        old_policy = deepcopy(self.policy)

        for module in old_policy.actor.modules():
            if isinstance(module, (nn.RNN, nn.GRU, nn.LSTM)):
                module.flatten_parameters()

        for module in old_policy.critic.modules():
            if isinstance(module, (nn.RNN, nn.GRU, nn.LSTM)):
                module.flatten_parameters()

        for _ in range(self.ppo_epoch):
            if self._use_recurrent_policy:
                # data_generator = buffer.recurrent_generator(advantages, self.num_mini_batch, self.data_chunk_length)
                data_generator = buffer.recurrent_generator_with_reflection(advantages, self.num_mini_batch,
                                                                            self.data_chunk_length)
            elif self._use_naive_recurrent:
                data_generator = buffer.naive_recurrent_generator(advantages, self.num_mini_batch)
            else:
                data_generator = buffer.feed_forward_generator(advantages, self.num_mini_batch)

            for sample in data_generator:
                value_loss, critic_grad_norm, policy_loss, dist_entropy, actor_grad_norm, imp_weights, r1_min, r1_max, target_kl, \
                    kl_approx_mean, biased_kl, r2_min, r2_max= self.ppo_update(sample, old_policy, step, update_actor)

                train_info['value_loss'] += value_loss.item()
                train_info['policy_loss'] += policy_loss.item()
                train_info['dist_entropy'] += dist_entropy.item()
                train_info['actor_grad_norm'] += actor_grad_norm
                train_info['critic_grad_norm'] += critic_grad_norm
                train_info['ratio'] += imp_weights.mean().item()

                train_info['r1_min'] += r1_min
                train_info['r2_min'] += r2_min
                train_info['r1_max'] += r1_max
                train_info['r2_max'] += r2_max
                train_info['target_kl'] += target_kl
                train_info['kl_approx_mean'] += kl_approx_mean
                train_info['biased_kl'] += biased_kl

        num_updates = self.ppo_epoch * self.num_mini_batch

        for k in train_info.keys():
            train_info[k] /= num_updates

        return train_info

    def prep_training(self):
        self.policy.actor.train()
        self.policy.critic.train()

    def prep_rollout(self):
        self.policy.actor.eval()
        self.policy.critic.eval()
